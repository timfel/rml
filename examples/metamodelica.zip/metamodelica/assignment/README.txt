
To run this program you can do in 3 ways:
- first 
  + with a file: cat ./program.txt | ./calc
- second
  + run ./calc
  + write some assingnments each on newline 
    then semicolon ";" then an expression 
    ex: a:=3
        b:=4
	;
	a+b
	hit CTRL+D
- third
  + ./runme.sh