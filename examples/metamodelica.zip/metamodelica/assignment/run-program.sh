#!/usr/bin/sh
./calc
