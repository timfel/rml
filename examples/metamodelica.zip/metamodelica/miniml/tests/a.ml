(* a.ml -- compute "5" *)
val five = 5
val it = print five
