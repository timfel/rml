#!/bin/bash

echo Running the experiment
./calc -log -young-size=16

