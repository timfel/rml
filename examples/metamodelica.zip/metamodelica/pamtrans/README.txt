
To run this program you can do in 3 ways:
- first 
  + with a file: cat ./program.txt | ./pamdecl
- second
  + run ./pamdecl
  + write/paste some program + hit CTRL+D
    - check program.txt for details
      and gram.y for grammar
- third
  + ./runme.sh