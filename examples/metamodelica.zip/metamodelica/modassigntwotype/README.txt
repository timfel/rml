
To run this program you can do in 3 ways:
- first 
  + with a file: cat ./program.txt | ./calc
- second
  + run ./calc
  + write some assingnments 
    ex: a:=(b:=4)/(c:=5)+10
	hit CTRL+D
- third
  + ./runme.sh