#!/bin/bash

echo Program for the calculator:
cat program.txt
echo "
"
echo Running the calculator on the program
cat program.txt | calc

echo "

"
