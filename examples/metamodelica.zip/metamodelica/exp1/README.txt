
To run this program you can do in 3 ways:
- first 
  + with a file: cat ./program.txt | ./calc
- second
  + run ./calc
  + write some expression
    ex: 1+6/3+15/5
	hit CTRL+D
- third
  + ./runme.sh