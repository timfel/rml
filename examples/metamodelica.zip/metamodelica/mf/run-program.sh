#!/usr/bin/sh
./mf
