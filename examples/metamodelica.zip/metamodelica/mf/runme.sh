#!/bin/bash

echo Running mini freja
./mf

echo "

"
