/* module Absyn */
#include "rml.h"
#include <stdlib.h>
#include <stdio.h>
RML_DEFINE_MODULE("Absyn")
extern RML_FORWARD_LABEL(RML__print);

RML_FORWARD_LABEL(Absyn__bindHOOK1);
static RML_FORWARD_LABEL(Absyn_2dsclam162);
static RML_FORWARD_LABEL(Absyn_2dsclam161);
static RML_FORWARD_LABEL(Absyn_2dsclam160);
static RML_FORWARD_LABEL(Absyn_2dsclam159);
static RML_FORWARD_LABEL(Absyn_2dsclam158);
static RML_FORWARD_LABEL(Absyn_2dsclam157);
static RML_FORWARD_LABEL(Absyn_2dsclam156);

static const RML_DEFSTRINGLIT(lit0,12,"BIND: HOOK1(");
static const RML_DEFSTRINGLIT(lit1,14,") => NAMEDECL(");
static const RML_DEFSTRINGLIT(lit2,2,", ");
static const RML_DEFSTRINGLIT(lit3,2,")\n");

extern void RML_5finit(void);

void Absyn_5finit(void)
{
	static int done = 0;
	if( done ) return;
	done = 1;
	RML_5finit();
}

RML_BEGIN_LABEL(Absyn__bindHOOK1)
{
	void *tmp163;
	RML_ALLOC(tmp163,2,4,Absyn__bindHOOK1);
	{ void *tmp121 = rmlSC;
	{ void *tmp120 = rmlFC;
	{ void *tmp164 = rmlSP;
	{ void *tmp122 = rmlA0;
	{ void *tmp123 = rmlA1;
	{ void *tmp124 = rmlA2;
	{ void *tmp125 = rmlA3;
	{ void *tmp139 = RML_FETCH(RML_UNTAGPTR(tmp125));
	switch( (rml_sint_t)tmp139 ) {
	case RML_STRUCTHDR(1,1):
	{ void *tmp140 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp125), 1));
	RML_STORE(tmp163, RML_IMMEDIATE(RML_STRUCTHDR(1,1)));
	RML_STORE(RML_OFFSET(tmp163, 1), tmp140);
	{ void *tmp141 = RML_TAGPTR(tmp163);
	rmlA0 = tmp141;
	RML_TAILCALL(RML_FETCH(tmp121),1);}}
	/*case RML_STRUCTHDR(1,0)*/
	default:
	{ void *tmp142 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp125), 1));
	{ void *tmp143 = rml_prim_marker();
	{ void *tmp146 = rml_prim_equal(tmp122, tmp142);
	switch( (rml_sint_t)tmp146 ) {
	case RML_TAGFIXNUM(0):
	rml_prim_unwind(tmp143);
	rmlA0 = tmp125;
	RML_TAILCALL(RML_FETCH(tmp121),1);
	default:
	RML_STORE(RML_OFFSET(tmp164, -1), tmp142);
	RML_STORE(RML_OFFSET(tmp164, -2), tmp120);
	RML_STORE(RML_OFFSET(tmp164, -3), tmp123);
	RML_STORE(RML_OFFSET(tmp164, -4), tmp124);
	RML_STORE(RML_OFFSET(tmp164, -5), tmp121);
	RML_STORE(RML_OFFSET(tmp164, -6), RML_LABVAL(Absyn_2dsclam162));
	rmlA0 = RML_REFSTRINGLIT(lit0);
	rmlSC = RML_OFFSET(tmp164, -6);
	rmlSP = RML_OFFSET(tmp164, -6);
	RML_TAILCALLQ(RML__print,1);
	}}}}
	}}}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam162)
{

	{ void *tmp167 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp167, 1));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp167, 2));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp167, 3));
	{ void *tmp120 = RML_FETCH(RML_OFFSET(tmp167, 4));
	{ void *tmp142 = RML_FETCH(RML_OFFSET(tmp167, 5));
	{ void *tmp166 = RML_OFFSET(tmp167, 6);
	RML_STORE(RML_OFFSET(tmp166, -1), tmp120);
	RML_STORE(RML_OFFSET(tmp166, -2), tmp123);
	RML_STORE(RML_OFFSET(tmp166, -3), tmp124);
	RML_STORE(RML_OFFSET(tmp166, -4), tmp121);
	RML_STORE(RML_OFFSET(tmp166, -5), RML_LABVAL(Absyn_2dsclam161));
	rmlA0 = tmp142;
	rmlFC = tmp120;
	rmlSC = RML_OFFSET(tmp166, -5);
	rmlSP = RML_OFFSET(tmp166, -5);
	RML_TAILCALLQ(RML__print,1);}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam161)
{

	{ void *tmp170 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp170, 1));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp170, 2));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp170, 3));
	{ void *tmp120 = RML_FETCH(RML_OFFSET(tmp170, 4));
	{ void *tmp169 = RML_OFFSET(tmp170, 5);
	RML_STORE(RML_OFFSET(tmp169, -1), tmp123);
	RML_STORE(RML_OFFSET(tmp169, -2), tmp120);
	RML_STORE(RML_OFFSET(tmp169, -3), tmp124);
	RML_STORE(RML_OFFSET(tmp169, -4), tmp121);
	RML_STORE(RML_OFFSET(tmp169, -5), RML_LABVAL(Absyn_2dsclam160));
	rmlA0 = RML_REFSTRINGLIT(lit1);
	rmlFC = tmp120;
	rmlSC = RML_OFFSET(tmp169, -5);
	rmlSP = RML_OFFSET(tmp169, -5);
	RML_TAILCALLQ(RML__print,1);}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam160)
{

	{ void *tmp173 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp173, 1));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp173, 2));
	{ void *tmp120 = RML_FETCH(RML_OFFSET(tmp173, 3));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp173, 4));
	{ void *tmp172 = RML_OFFSET(tmp173, 5);
	RML_STORE(RML_OFFSET(tmp172, -1), tmp120);
	RML_STORE(RML_OFFSET(tmp172, -2), tmp124);
	RML_STORE(RML_OFFSET(tmp172, -3), tmp123);
	RML_STORE(RML_OFFSET(tmp172, -4), tmp121);
	RML_STORE(RML_OFFSET(tmp172, -5), RML_LABVAL(Absyn_2dsclam159));
	rmlA0 = tmp123;
	rmlFC = tmp120;
	rmlSC = RML_OFFSET(tmp172, -5);
	rmlSP = RML_OFFSET(tmp172, -5);
	RML_TAILCALLQ(RML__print,1);}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam159)
{

	{ void *tmp176 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp176, 1));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp176, 2));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp176, 3));
	{ void *tmp120 = RML_FETCH(RML_OFFSET(tmp176, 4));
	{ void *tmp175 = RML_OFFSET(tmp176, 5);
	RML_STORE(RML_OFFSET(tmp175, -1), tmp124);
	RML_STORE(RML_OFFSET(tmp175, -2), tmp120);
	RML_STORE(RML_OFFSET(tmp175, -3), tmp123);
	RML_STORE(RML_OFFSET(tmp175, -4), tmp121);
	RML_STORE(RML_OFFSET(tmp175, -5), RML_LABVAL(Absyn_2dsclam158));
	rmlA0 = RML_REFSTRINGLIT(lit2);
	rmlFC = tmp120;
	rmlSC = RML_OFFSET(tmp175, -5);
	rmlSP = RML_OFFSET(tmp175, -5);
	RML_TAILCALLQ(RML__print,1);}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam158)
{

	{ void *tmp179 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp179, 1));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp179, 2));
	{ void *tmp120 = RML_FETCH(RML_OFFSET(tmp179, 3));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp179, 4));
	{ void *tmp178 = RML_OFFSET(tmp179, 5);
	RML_STORE(RML_OFFSET(tmp178, -1), tmp120);
	RML_STORE(RML_OFFSET(tmp178, -2), tmp123);
	RML_STORE(RML_OFFSET(tmp178, -3), tmp124);
	RML_STORE(RML_OFFSET(tmp178, -4), tmp121);
	RML_STORE(RML_OFFSET(tmp178, -5), RML_LABVAL(Absyn_2dsclam157));
	rmlA0 = tmp124;
	rmlFC = tmp120;
	rmlSC = RML_OFFSET(tmp178, -5);
	rmlSP = RML_OFFSET(tmp178, -5);
	RML_TAILCALLQ(RML__print,1);}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam157)
{

	{ void *tmp182 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp182, 1));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp182, 2));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp182, 3));
	{ void *tmp120 = RML_FETCH(RML_OFFSET(tmp182, 4));
	{ void *tmp181 = RML_OFFSET(tmp182, 5);
	RML_STORE(RML_OFFSET(tmp181, -1), tmp123);
	RML_STORE(RML_OFFSET(tmp181, -2), tmp124);
	RML_STORE(RML_OFFSET(tmp181, -3), tmp121);
	RML_STORE(RML_OFFSET(tmp181, -4), RML_LABVAL(Absyn_2dsclam156));
	rmlA0 = RML_REFSTRINGLIT(lit3);
	rmlFC = tmp120;
	rmlSC = RML_OFFSET(tmp181, -4);
	rmlSP = RML_OFFSET(tmp181, -4);
	RML_TAILCALLQ(RML__print,1);}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Absyn_2dsclam156)
{
	void *tmp183;
	RML_ALLOC(tmp183,5,0,Absyn_2dsclam156);
	{ void *tmp185 = rmlSC;
	{ void *tmp121 = RML_FETCH(RML_OFFSET(tmp185, 1));
	{ void *tmp124 = RML_FETCH(RML_OFFSET(tmp185, 2));
	{ void *tmp123 = RML_FETCH(RML_OFFSET(tmp185, 3));
	{ void *tmp184 = RML_OFFSET(tmp185, 4);
	RML_STORE(tmp183, RML_IMMEDIATE(RML_STRUCTHDR(2,0)));
	RML_STORE(RML_OFFSET(tmp183, 1), tmp123);
	RML_STORE(RML_OFFSET(tmp183, 2), tmp124);
	{ void *tmp154 = RML_TAGPTR(tmp183);
	RML_STORE(RML_OFFSET(tmp183, 3), RML_IMMEDIATE(RML_STRUCTHDR(1,1)));
	RML_STORE(RML_OFFSET(tmp183, 4), tmp154);
	{ void *tmp155 = RML_TAGPTR(RML_OFFSET(tmp183, 3));
	rmlA0 = tmp155;
	rmlSC = tmp121;
	rmlSP = tmp184;
	RML_TAILCALL(RML_FETCH(tmp121),1);}}}}}}}
}
RML_END_LABEL
