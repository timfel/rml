/* interface Main */
extern void Main_5finit(void);
extern RML_FORWARD_LABEL(Main__main);
