/* module Env */
#include "rml.h"
#include <stdlib.h>
#include <stdio.h>
RML_DEFINE_MODULE("Env")

RML_FORWARD_LABEL(Env__initial);
RML_FORWARD_LABEL(Env__lookup);
RML_FORWARD_LABEL(Env__lookuptype);
RML_FORWARD_LABEL(Env__update);

static const RML_DEFSTRINGLIT(lit0,5,"false");
static const RML_DEFSTRUCTLIT(lit1,1,2) {RML_IMMEDIATE(RML_TAGFIXNUM(0))}};
static const RML_DEFSTRUCTLIT(lit2,3,0) {RML_REFSTRINGLIT(lit0),RML_IMMEDIATE(RML_TAGFIXNUM(2)),RML_REFSTRUCTLIT(lit1)}};
static const RML_DEFSTRINGLIT(lit3,4,"true");
static const RML_DEFSTRUCTLIT(lit4,1,2) {RML_IMMEDIATE(RML_TAGFIXNUM(1))}};
static const RML_DEFSTRUCTLIT(lit5,3,0) {RML_REFSTRINGLIT(lit3),RML_IMMEDIATE(RML_TAGFIXNUM(2)),RML_REFSTRUCTLIT(lit4)}};
static const RML_DEFSTRUCT0LIT(lit6,0);
static const RML_DEFSTRUCTLIT(lit7,2,1) {RML_REFSTRUCTLIT(lit5),RML_REFSTRUCTLIT(lit6)}};
static const RML_DEFSTRUCTLIT(lit8,2,1) {RML_REFSTRUCTLIT(lit2),RML_REFSTRUCTLIT(lit7)}};

extern void RML_5finit(void);

void Env_5finit(void)
{
	static int done = 0;
	if( done ) return;
	done = 1;
	RML_5finit();
}

RML_BEGIN_LABEL(Env__initial)
{

	{ void *tmp162 = rmlSC;
	rmlA0 = RML_REFSTRUCTLIT(lit8);
	RML_TAILCALL(RML_FETCH(tmp162),1);}
}
RML_END_LABEL

RML_BEGIN_LABEL(Env__lookup)
{

	{ void *tmp158 = rmlSC;
	{ void *tmp157 = rmlFC;
	{ void *tmp159 = rmlA0;
	{ void *tmp160 = rmlA1;
	{ void *tmp179 = RML_FETCH(RML_UNTAGPTR(tmp159));
	switch( (rml_sint_t)tmp179 ) {
	case RML_STRUCTHDR(2,1):
	{ void *tmp180 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp159), 2));
	{ void *tmp181 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp159), 1));
	{ void *tmp182 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp181), 3));
	{ void *tmp183 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp181), 1));
	{ void *tmp184 = rml_prim_marker();
	{ void *tmp193 = rml_prim_equal(tmp160, tmp183);
	switch( (rml_sint_t)tmp193 ) {
	case RML_TAGFIXNUM(0):
	rml_prim_unwind(tmp184);
	rmlA0 = tmp180;
	RML_TAILCALLQ(Env__lookup,2);
	default:
	rmlA0 = tmp182;
	RML_TAILCALL(RML_FETCH(tmp158),1);
	}}}}}}}
	default:
	RML_TAILCALL(RML_FETCH(tmp157),0);
	}}}}}}
}
RML_END_LABEL

RML_BEGIN_LABEL(Env__lookuptype)
{

	{ void *tmp154 = rmlSC;
	{ void *tmp153 = rmlFC;
	{ void *tmp155 = rmlA0;
	{ void *tmp156 = rmlA1;
	{ void *tmp204 = RML_FETCH(RML_UNTAGPTR(tmp155));
	switch( (rml_sint_t)tmp204 ) {
	case RML_STRUCTHDR(2,1):
	{ void *tmp205 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp155), 2));
	{ void *tmp206 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp155), 1));
	{ void *tmp207 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp206), 2));
	{ void *tmp208 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp206), 1));
	{ void *tmp209 = rml_prim_marker();
	{ void *tmp218 = rml_prim_equal(tmp156, tmp208);
	switch( (rml_sint_t)tmp218 ) {
	case RML_TAGFIXNUM(0):
	rml_prim_unwind(tmp209);
	rmlA0 = tmp205;
	RML_TAILCALLQ(Env__lookuptype,2);
	default:
	rmlA0 = tmp207;
	RML_TAILCALL(RML_FETCH(tmp154),1);
	}}}}}}}
	default:
	RML_TAILCALL(RML_FETCH(tmp153),0);
	}}}}}}
}
RML_END_LABEL

RML_BEGIN_LABEL(Env__update)
{
	void *tmp231;
	RML_ALLOC(tmp231,7,4,Env__update);
	{ void *tmp148 = rmlSC;
	{ void *tmp149 = rmlA0;
	{ void *tmp150 = rmlA1;
	{ void *tmp151 = rmlA2;
	{ void *tmp152 = rmlA3;
	RML_STORE(tmp231, RML_IMMEDIATE(RML_STRUCTHDR(3,0)));
	RML_STORE(RML_OFFSET(tmp231, 1), tmp150);
	RML_STORE(RML_OFFSET(tmp231, 2), tmp151);
	RML_STORE(RML_OFFSET(tmp231, 3), tmp152);
	{ void *tmp225 = RML_TAGPTR(tmp231);
	RML_STORE(RML_OFFSET(tmp231, 4), RML_IMMEDIATE(RML_STRUCTHDR(2,1)));
	RML_STORE(RML_OFFSET(tmp231, 5), tmp225);
	RML_STORE(RML_OFFSET(tmp231, 6), tmp149);
	{ void *tmp226 = RML_TAGPTR(RML_OFFSET(tmp231, 4));
	rmlA0 = tmp226;
	RML_TAILCALL(RML_FETCH(tmp148),1);}}}}}}}
}
RML_END_LABEL
