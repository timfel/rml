/* module Main */
#include "rml.h"
#include <stdlib.h>
#include <stdio.h>
RML_DEFINE_MODULE("Main")
extern RML_FORWARD_LABEL(Eval__evalprog);
extern RML_FORWARD_LABEL(RML__print);
extern RML_FORWARD_LABEL(Absyn__bindHOOK1);
extern RML_FORWARD_LABEL(RML__list_5fappend);

RML_FORWARD_LABEL(Main__main);
static RML_FORWARD_LABEL(Main_2dsclam461);
static RML_FORWARD_LABEL(Main_2dsclam460);
static RML_FORWARD_LABEL(Main_2dsclam485);
static RML_FORWARD_LABEL(Main_2dsclam484);
static RML_FORWARD_LABEL(Main_2dsclam411);
static RML_FORWARD_LABEL(Main_2dsclam410);
static RML_FORWARD_LABEL(Main_2dsclam483);
static RML_FORWARD_LABEL(Main_2dsclam355);
static RML_FORWARD_LABEL(Main__check);
static RML_FORWARD_LABEL(Main_2dsclam440);
static RML_FORWARD_LABEL(Main_2dsclam439);
static RML_FORWARD_LABEL(Main_2dsclam438);
static RML_FORWARD_LABEL(Main_2dsclam433);
static RML_FORWARD_LABEL(Main__buildNormalDeclList);
static RML_FORWARD_LABEL(Main_2dsclam387);
static RML_FORWARD_LABEL(Main__bind_5fhook1);
static RML_FORWARD_LABEL(Main_2dsclam258);
static RML_FORWARD_LABEL(Main__bind);
static RML_FORWARD_LABEL(Main_2dsclam341);
static RML_FORWARD_LABEL(Main_2dfclam333);
static RML_FORWARD_LABEL(Main_2dsclam329);
static RML_FORWARD_LABEL(Main_2dlab312);
static RML_FORWARD_LABEL(Main_2dsclam311);
static RML_FORWARD_LABEL(Main_2dsclam310);

static const RML_DEFSTRUCT0LIT(lit0,0);
static const RML_DEFSTRINGLIT(lit1,6,"Hook :");
static const RML_DEFSTRINGLIT(lit2,11," not bound!");
static const RML_DEFSTRINGLIT(lit3,5,"hook1");
static const RML_DEFSTRUCTLIT(lit4,1,0) {RML_REFSTRINGLIT(lit3)}};
static const RML_DEFSTRINGLIT(lit5,5,"hook2");
static const RML_DEFSTRUCTLIT(lit6,1,0) {RML_REFSTRINGLIT(lit5)}};
static const RML_DEFSTRINGLIT(lit7,5,"hook3");
static const RML_DEFSTRUCTLIT(lit8,1,0) {RML_REFSTRINGLIT(lit7)}};
static const RML_DEFSTRUCTLIT(lit9,2,1) {RML_REFSTRUCTLIT(lit8),RML_REFSTRUCTLIT(lit0)}};
static const RML_DEFSTRUCTLIT(lit10,2,1) {RML_REFSTRUCTLIT(lit6),RML_REFSTRUCTLIT(lit9)}};
static const RML_DEFSTRUCTLIT(lit11,2,1) {RML_REFSTRUCTLIT(lit4),RML_REFSTRUCTLIT(lit10)}};
static const RML_DEFSTRINGLIT(lit12,2,"i1");
static const RML_DEFSTRUCTLIT(lit13,1,0) {RML_IMMEDIATE(RML_TAGFIXNUM(1))}};
static const RML_DEFSTRUCTLIT(lit14,2,0) {RML_REFSTRINGLIT(lit12),RML_REFSTRUCTLIT(lit13)}};
static const RML_DEFSTRINGLIT(lit15,2,"i2");
static const RML_DEFSTRUCTLIT(lit16,1,0) {RML_IMMEDIATE(RML_TAGFIXNUM(5))}};
static const RML_DEFSTRUCTLIT(lit17,2,0) {RML_REFSTRINGLIT(lit15),RML_REFSTRUCTLIT(lit16)}};
static const RML_DEFSTRINGLIT(lit18,2,"i3");
static const RML_DEFSTRUCTLIT(lit19,1,5) {RML_REFSTRINGLIT(lit12)}};
static const RML_DEFSTRUCTLIT(lit20,1,5) {RML_REFSTRINGLIT(lit15)}};
static const RML_DEFSTRUCTLIT(lit21,3,2) {RML_REFSTRUCTLIT(lit19),RML_IMMEDIATE(RML_TAGFIXNUM(0)),RML_REFSTRUCTLIT(lit20)}};
static const RML_DEFSTRUCTLIT(lit22,2,0) {RML_REFSTRINGLIT(lit18),RML_REFSTRUCTLIT(lit21)}};
static const RML_DEFSTRUCTLIT(lit23,1,5) {RML_REFSTRINGLIT(lit18)}};
static const RML_DEFSTRUCTLIT(lit24,1,1) {RML_REFSTRUCTLIT(lit23)}};
static const RML_DEFSTRUCTLIT(lit25,2,1) {RML_REFSTRUCTLIT(lit24),RML_REFSTRUCTLIT(lit0)}};
static const RML_DEFSTRUCTLIT(lit26,2,1) {RML_REFSTRUCTLIT(lit22),RML_REFSTRUCTLIT(lit25)}};
static const RML_DEFSTRUCTLIT(lit27,2,1) {RML_REFSTRUCTLIT(lit17),RML_REFSTRUCTLIT(lit26)}};
static const RML_DEFSTRUCTLIT(lit28,2,1) {RML_REFSTRUCTLIT(lit14),RML_REFSTRUCTLIT(lit27)}};
static const RML_DEFSTRUCTLIT(lit29,2,0) {RML_REFSTRUCTLIT(lit11),RML_REFSTRUCTLIT(lit28)}};
static const RML_DEFSTRINGLIT(lit30,7,"integer");
static const RML_DEFSTRINGLIT(lit31,4,"real");
static const RML_DEFSTRINGLIT(lit32,45,"Instantiated the component, bound the hooks!\n");
static const RML_DEFSTRINGLIT(lit33,29,"\nnot all hooks instantiated!\n");

extern void ScanParse_5finit(void);
extern void Eval_5finit(void);
extern void Absyn_5finit(void);
extern void RML_5finit(void);

void Main_5finit(void)
{
	static int done = 0;
	if( done ) return;
	done = 1;
	ScanParse_5finit();
	Eval_5finit();
	Absyn_5finit();
	RML_5finit();
}

RML_BEGIN_LABEL(Main__main)
{

	{ void *tmp240 = rmlSC;
	{ void *tmp239 = rmlFC;
	{ void *tmp530 = rmlSP;
	RML_STORE(RML_OFFSET(tmp530, -1), tmp239);
	RML_STORE(RML_OFFSET(tmp530, -2), tmp240);
	RML_STORE(RML_OFFSET(tmp530, -3), RML_LABVAL(Main_2dsclam461));
	rmlA3 = RML_REFSTRINGLIT(lit30);
	rmlA2 = RML_REFSTRINGLIT(lit12);
	rmlA1 = RML_REFSTRINGLIT(lit3);
	rmlA0 = RML_REFSTRUCTLIT(lit29);
	rmlSC = RML_OFFSET(tmp530, -3);
	rmlSP = RML_OFFSET(tmp530, -3);
	RML_TAILCALLQ(Main__bind_5fhook1,4);}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam461)
{

	{ void *tmp533 = rmlSC;
	{ void *tmp240 = RML_FETCH(RML_OFFSET(tmp533, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp533, 2));
	{ void *tmp532 = RML_OFFSET(tmp533, 3);
	RML_STORE(RML_OFFSET(tmp532, -1), tmp239);
	RML_STORE(RML_OFFSET(tmp532, -2), tmp240);
	RML_STORE(RML_OFFSET(tmp532, -3), RML_LABVAL(Main_2dsclam460));
	rmlA3 = RML_REFSTRINGLIT(lit31);
	rmlA2 = RML_REFSTRINGLIT(lit15);
	rmlA1 = RML_REFSTRINGLIT(lit5);
	rmlFC = tmp239;
	rmlSC = RML_OFFSET(tmp532, -3);
	rmlSP = RML_OFFSET(tmp532, -3);
	RML_TAILCALLQ(Main__bind_5fhook1,4);}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam460)
{

	{ void *tmp536 = rmlSC;
	{ void *tmp240 = RML_FETCH(RML_OFFSET(tmp536, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp536, 2));
	{ void *tmp535 = RML_OFFSET(tmp536, 3);
	RML_STORE(RML_OFFSET(tmp535, -1), tmp239);
	RML_STORE(RML_OFFSET(tmp535, -2), tmp240);
	RML_STORE(RML_OFFSET(tmp535, -3), RML_LABVAL(Main_2dsclam485));
	rmlA3 = RML_REFSTRINGLIT(lit31);
	rmlA2 = RML_REFSTRINGLIT(lit18);
	rmlA1 = RML_REFSTRINGLIT(lit7);
	rmlFC = tmp239;
	rmlSC = RML_OFFSET(tmp535, -3);
	rmlSP = RML_OFFSET(tmp535, -3);
	RML_TAILCALLQ(Main__bind_5fhook1,4);}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam485)
{

	{ void *tmp539 = rmlSC;
	{ void *tmp240 = RML_FETCH(RML_OFFSET(tmp539, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp539, 2));
	{ void *tmp538 = RML_OFFSET(tmp539, 3);
	{ void *tmp465 = rmlA0;
	RML_STORE(RML_OFFSET(tmp538, -1), tmp465);
	RML_STORE(RML_OFFSET(tmp538, -2), tmp239);
	RML_STORE(RML_OFFSET(tmp538, -3), tmp240);
	RML_STORE(RML_OFFSET(tmp538, -4), RML_LABVAL(Main_2dsclam484));
	rmlA0 = RML_REFSTRINGLIT(lit32);
	rmlFC = tmp239;
	rmlSC = RML_OFFSET(tmp538, -4);
	rmlSP = RML_OFFSET(tmp538, -4);
	RML_TAILCALLQ(RML__print,1);}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam484)
{

	{ void *tmp542 = rmlSC;
	{ void *tmp240 = RML_FETCH(RML_OFFSET(tmp542, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp542, 2));
	{ void *tmp465 = RML_FETCH(RML_OFFSET(tmp542, 3));
	{ void *tmp541 = RML_OFFSET(tmp542, 4);
	RML_STORE(RML_OFFSET(tmp541, -1), tmp465);
	RML_STORE(RML_OFFSET(tmp541, -2), tmp239);
	RML_STORE(RML_OFFSET(tmp541, -3), tmp240);
	RML_STORE(RML_OFFSET(tmp541, -4), RML_LABVAL(Main_2dsclam483));
	{ void *tmp222 = RML_OFFSET(tmp541, -4);
	{ void *tmp402 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp465), 1));
	RML_STORE(RML_OFFSET(tmp541, -5), tmp239);
	RML_STORE(RML_OFFSET(tmp541, -6), tmp222);
	RML_STORE(RML_OFFSET(tmp541, -7), RML_LABVAL(Main_2dsclam411));
	rmlA0 = tmp402;
	rmlFC = tmp239;
	rmlSC = RML_OFFSET(tmp541, -7);
	rmlSP = RML_OFFSET(tmp541, -7);
	RML_TAILCALLQ(Main__check,1);}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam411)
{

	{ void *tmp551 = rmlSC;
	{ void *tmp222 = RML_FETCH(RML_OFFSET(tmp551, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp551, 2));
	{ void *tmp550 = RML_OFFSET(tmp551, 3);
	{ void *tmp404 = rmlA0;
	switch( (rml_sint_t)tmp404 ) {
	case RML_TAGFIXNUM(0):
	RML_STORE(RML_OFFSET(tmp550, -1), tmp222);
	RML_STORE(RML_OFFSET(tmp550, -2), RML_LABVAL(Main_2dsclam410));
	rmlA0 = RML_REFSTRINGLIT(lit33);
	rmlFC = tmp239;
	rmlSC = RML_OFFSET(tmp550, -2);
	rmlSP = RML_OFFSET(tmp550, -2);
	RML_TAILCALLQ(RML__print,1);
	/*case RML_TAGFIXNUM(1)*/
	default:
	rmlA0 = RML_IMMEDIATE(RML_TAGFIXNUM(1));
	rmlSC = tmp222;
	rmlSP = tmp550;
	RML_TAILCALL(RML_FETCH(tmp222),1);
	}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam410)
{

	{ void *tmp554 = rmlSC;
	{ void *tmp222 = RML_FETCH(RML_OFFSET(tmp554, 1));
	{ void *tmp553 = RML_OFFSET(tmp554, 2);
	rmlA0 = RML_IMMEDIATE(RML_TAGFIXNUM(0));
	rmlSC = tmp222;
	rmlSP = tmp553;
	RML_TAILCALL(RML_FETCH(tmp222),1);}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam483)
{

	{ void *tmp545 = rmlSC;
	{ void *tmp240 = RML_FETCH(RML_OFFSET(tmp545, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp545, 2));
	{ void *tmp465 = RML_FETCH(RML_OFFSET(tmp545, 3));
	{ void *tmp544 = RML_OFFSET(tmp545, 4);
	{ void *tmp471 = rmlA0;
	switch( (rml_sint_t)tmp471 ) {
	case RML_TAGFIXNUM(1):
	{ void *tmp347 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp465), 2));
	{ void *tmp348 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp465), 1));
	RML_STORE(RML_OFFSET(tmp544, -1), tmp347);
	RML_STORE(RML_OFFSET(tmp544, -2), tmp239);
	RML_STORE(RML_OFFSET(tmp544, -3), tmp240);
	RML_STORE(RML_OFFSET(tmp544, -4), RML_LABVAL(Main_2dsclam355));
	rmlA0 = tmp348;
	rmlFC = tmp239;
	rmlSC = RML_OFFSET(tmp544, -4);
	rmlSP = RML_OFFSET(tmp544, -4);
	RML_TAILCALLQ(Main__buildNormalDeclList,1);}}
	default:
	rmlFC = tmp239;
	rmlSP = tmp544;
	RML_TAILCALL(RML_FETCH(tmp239),0);
	}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam355)
{
	void *tmp546;
	RML_ALLOC(tmp546,3,1,Main_2dsclam355);
	{ void *tmp548 = rmlSC;
	{ void *tmp240 = RML_FETCH(RML_OFFSET(tmp548, 1));
	{ void *tmp239 = RML_FETCH(RML_OFFSET(tmp548, 2));
	{ void *tmp347 = RML_FETCH(RML_OFFSET(tmp548, 3));
	{ void *tmp547 = RML_OFFSET(tmp548, 4);
	{ void *tmp350 = rmlA0;
	RML_STORE(tmp546, RML_IMMEDIATE(RML_STRUCTHDR(2,0)));
	RML_STORE(RML_OFFSET(tmp546, 1), tmp350);
	RML_STORE(RML_OFFSET(tmp546, 2), tmp347);
	{ void *tmp354 = RML_TAGPTR(tmp546);
	rmlA0 = tmp354;
	rmlFC = tmp239;
	rmlSC = tmp240;
	rmlSP = tmp547;
	RML_TAILCALLQ(Eval__evalprog,1);}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main__check)
{

	{ void *tmp219 = rmlSC;
	{ void *tmp218 = rmlFC;
	{ void *tmp516 = rmlSP;
	{ void *tmp220 = rmlA0;
	{ void *tmp424 = RML_FETCH(RML_UNTAGPTR(tmp220));
	switch( (rml_sint_t)tmp424 ) {
	case RML_STRUCTHDR(0,0):
	rmlA0 = RML_IMMEDIATE(RML_TAGFIXNUM(1));
	RML_TAILCALL(RML_FETCH(tmp219),1);
	/*case RML_STRUCTHDR(2,1)*/
	default:
	{ void *tmp425 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp220), 2));
	{ void *tmp426 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp220), 1));
	{ void *tmp427 = RML_FETCH(RML_UNTAGPTR(tmp426));
	switch( (rml_sint_t)tmp427 ) {
	case RML_STRUCTHDR(1,1):
	RML_STORE(RML_OFFSET(tmp516, -1), tmp219);
	RML_STORE(RML_OFFSET(tmp516, -2), tmp218);
	RML_STORE(RML_OFFSET(tmp516, -3), RML_LABVAL(Main_2dsclam433));
	rmlA0 = tmp425;
	rmlSC = RML_OFFSET(tmp516, -3);
	rmlSP = RML_OFFSET(tmp516, -3);
	RML_TAILCALLQ(Main__check,1);
	/*case RML_STRUCTHDR(1,0)*/
	default:
	{ void *tmp434 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp426), 1));
	RML_STORE(RML_OFFSET(tmp516, -1), tmp434);
	RML_STORE(RML_OFFSET(tmp516, -2), tmp218);
	RML_STORE(RML_OFFSET(tmp516, -3), tmp219);
	RML_STORE(RML_OFFSET(tmp516, -4), RML_LABVAL(Main_2dsclam440));
	rmlA0 = RML_REFSTRINGLIT(lit1);
	rmlSC = RML_OFFSET(tmp516, -4);
	rmlSP = RML_OFFSET(tmp516, -4);
	RML_TAILCALLQ(RML__print,1);}
	}}}}
	}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam440)
{

	{ void *tmp522 = rmlSC;
	{ void *tmp219 = RML_FETCH(RML_OFFSET(tmp522, 1));
	{ void *tmp218 = RML_FETCH(RML_OFFSET(tmp522, 2));
	{ void *tmp434 = RML_FETCH(RML_OFFSET(tmp522, 3));
	{ void *tmp521 = RML_OFFSET(tmp522, 4);
	RML_STORE(RML_OFFSET(tmp521, -1), tmp218);
	RML_STORE(RML_OFFSET(tmp521, -2), tmp219);
	RML_STORE(RML_OFFSET(tmp521, -3), RML_LABVAL(Main_2dsclam439));
	rmlA0 = tmp434;
	rmlFC = tmp218;
	rmlSC = RML_OFFSET(tmp521, -3);
	rmlSP = RML_OFFSET(tmp521, -3);
	RML_TAILCALLQ(RML__print,1);}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam439)
{

	{ void *tmp525 = rmlSC;
	{ void *tmp219 = RML_FETCH(RML_OFFSET(tmp525, 1));
	{ void *tmp218 = RML_FETCH(RML_OFFSET(tmp525, 2));
	{ void *tmp524 = RML_OFFSET(tmp525, 3);
	RML_STORE(RML_OFFSET(tmp524, -1), tmp219);
	RML_STORE(RML_OFFSET(tmp524, -2), RML_LABVAL(Main_2dsclam438));
	rmlA0 = RML_REFSTRINGLIT(lit2);
	rmlFC = tmp218;
	rmlSC = RML_OFFSET(tmp524, -2);
	rmlSP = RML_OFFSET(tmp524, -2);
	RML_TAILCALLQ(RML__print,1);}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam438)
{

	{ void *tmp528 = rmlSC;
	{ void *tmp219 = RML_FETCH(RML_OFFSET(tmp528, 1));
	{ void *tmp527 = RML_OFFSET(tmp528, 2);
	rmlA0 = RML_IMMEDIATE(RML_TAGFIXNUM(0));
	rmlSC = tmp219;
	rmlSP = tmp527;
	RML_TAILCALL(RML_FETCH(tmp219),1);}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam433)
{

	{ void *tmp519 = rmlSC;
	{ void *tmp218 = RML_FETCH(RML_OFFSET(tmp519, 1));
	{ void *tmp219 = RML_FETCH(RML_OFFSET(tmp519, 2));
	{ void *tmp518 = RML_OFFSET(tmp519, 3);
	{ void *tmp429 = rmlA0;
	switch( (rml_sint_t)tmp429 ) {
	case RML_TAGFIXNUM(1):
	rmlA0 = RML_IMMEDIATE(RML_TAGFIXNUM(1));
	rmlSC = tmp219;
	rmlSP = tmp518;
	RML_TAILCALL(RML_FETCH(tmp219),1);
	default:
	rmlFC = tmp218;
	rmlSP = tmp518;
	RML_TAILCALL(RML_FETCH(tmp218),0);
	}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main__buildNormalDeclList)
{
	void *tmp510;
	RML_ALLOC(tmp510,3,1,Main__buildNormalDeclList);
	{ void *tmp213 = rmlSC;
	{ void *tmp212 = rmlFC;
	{ void *tmp511 = rmlSP;
	{ void *tmp214 = rmlA0;
	{ void *tmp389 = RML_FETCH(RML_UNTAGPTR(tmp214));
	switch( (rml_sint_t)tmp389 ) {
	case RML_STRUCTHDR(2,1):
	{ void *tmp390 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp214), 2));
	{ void *tmp391 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp214), 1));
	{ void *tmp392 = RML_FETCH(RML_UNTAGPTR(tmp391));
	switch( (rml_sint_t)tmp392 ) {
	case RML_STRUCTHDR(1,0):
	RML_TAILCALL(RML_FETCH(tmp212),0);
	/*case RML_STRUCTHDR(1,1)*/
	default:
	{ void *tmp393 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp391), 1));
	{ void *tmp394 = RML_FETCH(RML_UNTAGPTR(tmp390));
	switch( (rml_sint_t)tmp394 ) {
	case RML_STRUCTHDR(0,0):
	RML_STORE(tmp510, RML_IMMEDIATE(RML_STRUCTHDR(2,1)));
	RML_STORE(RML_OFFSET(tmp510, 1), tmp393);
	RML_STORE(RML_OFFSET(tmp510, 2), RML_REFSTRUCTLIT(lit0));
	{ void *tmp397 = RML_TAGPTR(tmp510);
	rmlA0 = tmp397;
	RML_TAILCALL(RML_FETCH(tmp213),1);}
	default:
	RML_STORE(RML_OFFSET(tmp511, -1), tmp393);
	RML_STORE(RML_OFFSET(tmp511, -2), tmp212);
	RML_STORE(RML_OFFSET(tmp511, -3), tmp213);
	RML_STORE(RML_OFFSET(tmp511, -4), RML_LABVAL(Main_2dsclam387));
	rmlA0 = tmp390;
	rmlSC = RML_OFFSET(tmp511, -4);
	rmlSP = RML_OFFSET(tmp511, -4);
	RML_TAILCALLQ(Main__buildNormalDeclList,1);
	}}}
	}}}}
	default:
	RML_TAILCALL(RML_FETCH(tmp212),0);
	}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam387)
{
	void *tmp512;
	RML_ALLOC(tmp512,3,1,Main_2dsclam387);
	{ void *tmp514 = rmlSC;
	{ void *tmp213 = RML_FETCH(RML_OFFSET(tmp514, 1));
	{ void *tmp212 = RML_FETCH(RML_OFFSET(tmp514, 2));
	{ void *tmp393 = RML_FETCH(RML_OFFSET(tmp514, 3));
	{ void *tmp513 = RML_OFFSET(tmp514, 4);
	{ void *tmp376 = rmlA0;
	RML_STORE(tmp512, RML_IMMEDIATE(RML_STRUCTHDR(2,1)));
	RML_STORE(RML_OFFSET(tmp512, 1), tmp393);
	RML_STORE(RML_OFFSET(tmp512, 2), RML_REFSTRUCTLIT(lit0));
	{ void *tmp380 = RML_TAGPTR(tmp512);
	rmlA1 = tmp376;
	rmlA0 = tmp380;
	rmlFC = tmp212;
	rmlSC = tmp213;
	rmlSP = tmp513;
	RML_TAILCALLQ(RML__list_5fappend,2);}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main__bind_5fhook1)
{

	{ void *tmp231 = rmlSC;
	{ void *tmp506 = rmlSP;
	{ void *tmp232 = rmlA0;
	{ void *tmp250 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp232), 2));
	{ void *tmp251 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp232), 1));
	RML_STORE(RML_OFFSET(tmp506, -1), tmp250);
	RML_STORE(RML_OFFSET(tmp506, -2), tmp231);
	RML_STORE(RML_OFFSET(tmp506, -3), RML_LABVAL(Main_2dsclam258));
	rmlA0 = tmp251;
	rmlSC = RML_OFFSET(tmp506, -3);
	rmlSP = RML_OFFSET(tmp506, -3);
	RML_TAILCALLQ(Main__bind,4);}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam258)
{
	void *tmp507;
	RML_ALLOC(tmp507,3,1,Main_2dsclam258);
	{ void *tmp509 = rmlSC;
	{ void *tmp231 = RML_FETCH(RML_OFFSET(tmp509, 1));
	{ void *tmp250 = RML_FETCH(RML_OFFSET(tmp509, 2));
	{ void *tmp508 = RML_OFFSET(tmp509, 3);
	{ void *tmp253 = rmlA0;
	RML_STORE(tmp507, RML_IMMEDIATE(RML_STRUCTHDR(2,0)));
	RML_STORE(RML_OFFSET(tmp507, 1), tmp253);
	RML_STORE(RML_OFFSET(tmp507, 2), tmp250);
	{ void *tmp257 = RML_TAGPTR(tmp507);
	rmlA0 = tmp257;
	rmlSC = tmp231;
	rmlSP = tmp508;
	RML_TAILCALL(RML_FETCH(tmp231),1);}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main__bind)
{
	void *tmp486;
	RML_ALLOC(tmp486,2,4,Main__bind);
	{ void *tmp225 = rmlSC;
	{ void *tmp224 = rmlFC;
	{ void *tmp487 = rmlSP;
	{ void *tmp226 = rmlA0;
	{ void *tmp227 = rmlA1;
	{ void *tmp228 = rmlA2;
	{ void *tmp229 = rmlA3;
	{ void *tmp313 = RML_FETCH(RML_UNTAGPTR(tmp226));
	switch( (rml_sint_t)tmp313 ) {
	case RML_STRUCTHDR(2,1):
	{ void *tmp314 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp226), 2));
	{ void *tmp315 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp226), 1));
	{ void *tmp316 = RML_FETCH(RML_UNTAGPTR(tmp315));
	switch( (rml_sint_t)tmp316 ) {
	case RML_STRUCTHDR(1,1):
	RML_STORE(RML_OFFSET(tmp487, -1), tmp315);
	RML_STORE(RML_OFFSET(tmp487, -2), tmp224);
	RML_STORE(RML_OFFSET(tmp487, -3), tmp225);
	RML_STORE(RML_OFFSET(tmp487, -4), RML_LABVAL(Main_2dsclam329));
	rmlA0 = tmp314;
	rmlSC = RML_OFFSET(tmp487, -4);
	rmlSP = RML_OFFSET(tmp487, -4);
	RML_TAILCALLQ(Main__bind,4);
	/*case RML_STRUCTHDR(1,0)*/
	default:
	{ void *tmp330 = RML_FETCH(RML_OFFSET(RML_UNTAGPTR(tmp315), 1));
	{ void *tmp331 = RML_FETCH(RML_UNTAGPTR(tmp314));
	switch( (rml_sint_t)tmp331 ) {
	case RML_STRUCTHDR(0,0):
	RML_STORE(tmp486, RML_IMMEDIATE(RML_STRUCTHDR(1,0)));
	RML_STORE(RML_OFFSET(tmp486, 1), tmp330);
	{ void *tmp334 = RML_TAGPTR(tmp486);
	RML_STORE(RML_OFFSET(tmp487, -1), tmp224);
	RML_STORE(RML_OFFSET(tmp487, -2), tmp229);
	RML_STORE(RML_OFFSET(tmp487, -3), tmp228);
	RML_STORE(RML_OFFSET(tmp487, -4), tmp227);
	RML_STORE(RML_OFFSET(tmp487, -5), tmp314);
	RML_STORE(RML_OFFSET(tmp487, -6), tmp330);
	RML_STORE(RML_OFFSET(tmp487, -7), tmp225);
	RML_STORE(RML_OFFSET(tmp487, -8), RML_LABVAL(Main_2dfclam333));
	RML_STORE(RML_OFFSET(tmp487, -9), tmp225);
	RML_STORE(RML_OFFSET(tmp487, -10), RML_LABVAL(Main_2dsclam341));
	rmlA3 = tmp334;
	rmlA2 = tmp229;
	rmlA1 = tmp228;
	rmlA0 = tmp227;
	rmlFC = RML_OFFSET(tmp487, -8);
	rmlSC = RML_OFFSET(tmp487, -10);
	rmlSP = RML_OFFSET(tmp487, -10);
	RML_TAILCALLQ(Absyn__bindHOOK1,4);}
	default:
	rmlA6 = tmp330;
	rmlA5 = tmp314;
	rmlA4 = tmp227;
	rmlA3 = tmp228;
	rmlA2 = tmp229;
	rmlA1 = tmp224;
	rmlA0 = tmp225;
	RML_TAILCALLQ(Main_2dlab312,7);
	}}}
	}}}}
	default:
	RML_TAILCALL(RML_FETCH(tmp224),0);
	}}}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam341)
{
	void *tmp502;
	RML_ALLOC(tmp502,3,1,Main_2dsclam341);
	{ void *tmp504 = rmlSC;
	{ void *tmp225 = RML_FETCH(RML_OFFSET(tmp504, 1));
	{ void *tmp503 = RML_OFFSET(tmp504, 2);
	{ void *tmp336 = rmlA0;
	RML_STORE(tmp502, RML_IMMEDIATE(RML_STRUCTHDR(2,1)));
	RML_STORE(RML_OFFSET(tmp502, 1), tmp336);
	RML_STORE(RML_OFFSET(tmp502, 2), RML_REFSTRUCTLIT(lit0));
	{ void *tmp340 = RML_TAGPTR(tmp502);
	rmlA0 = tmp340;
	rmlSC = tmp225;
	rmlSP = tmp503;
	RML_TAILCALL(RML_FETCH(tmp225),1);}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dfclam333)
{

	{ void *tmp501 = rmlFC;
	{ void *tmp225 = RML_FETCH(RML_OFFSET(tmp501, 1));
	{ void *tmp330 = RML_FETCH(RML_OFFSET(tmp501, 2));
	{ void *tmp314 = RML_FETCH(RML_OFFSET(tmp501, 3));
	{ void *tmp227 = RML_FETCH(RML_OFFSET(tmp501, 4));
	{ void *tmp228 = RML_FETCH(RML_OFFSET(tmp501, 5));
	{ void *tmp229 = RML_FETCH(RML_OFFSET(tmp501, 6));
	{ void *tmp224 = RML_FETCH(RML_OFFSET(tmp501, 7));
	{ void *tmp500 = RML_OFFSET(tmp501, 8);
	rmlA6 = tmp330;
	rmlA5 = tmp314;
	rmlA4 = tmp227;
	rmlA3 = tmp228;
	rmlA2 = tmp229;
	rmlA1 = tmp224;
	rmlA0 = tmp225;
	rmlSP = tmp500;
	RML_TAILCALLQ(Main_2dlab312,7);}}}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam329)
{
	void *tmp496;
	RML_ALLOC(tmp496,3,1,Main_2dsclam329);
	{ void *tmp498 = rmlSC;
	{ void *tmp225 = RML_FETCH(RML_OFFSET(tmp498, 1));
	{ void *tmp224 = RML_FETCH(RML_OFFSET(tmp498, 2));
	{ void *tmp315 = RML_FETCH(RML_OFFSET(tmp498, 3));
	{ void *tmp497 = RML_OFFSET(tmp498, 4);
	{ void *tmp318 = rmlA0;
	RML_STORE(tmp496, RML_IMMEDIATE(RML_STRUCTHDR(2,1)));
	RML_STORE(RML_OFFSET(tmp496, 1), tmp315);
	RML_STORE(RML_OFFSET(tmp496, 2), RML_REFSTRUCTLIT(lit0));
	{ void *tmp322 = RML_TAGPTR(tmp496);
	rmlA1 = tmp318;
	rmlA0 = tmp322;
	rmlFC = tmp224;
	rmlSC = tmp225;
	rmlSP = tmp497;
	RML_TAILCALLQ(RML__list_5fappend,2);}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dlab312)
{

	{ void *tmp489 = rmlSP;
	{ void *tmp225 = rmlA0;
	{ void *tmp286 = rmlA1;
	{ void *tmp287 = rmlA2;
	{ void *tmp288 = rmlA3;
	{ void *tmp289 = rmlA4;
	{ void *tmp290 = rmlA5;
	{ void *tmp291 = rmlA6;
	RML_STORE(RML_OFFSET(tmp489, -1), tmp291);
	RML_STORE(RML_OFFSET(tmp489, -2), tmp289);
	RML_STORE(RML_OFFSET(tmp489, -3), tmp288);
	RML_STORE(RML_OFFSET(tmp489, -4), tmp287);
	RML_STORE(RML_OFFSET(tmp489, -5), tmp286);
	RML_STORE(RML_OFFSET(tmp489, -6), tmp225);
	RML_STORE(RML_OFFSET(tmp489, -7), RML_LABVAL(Main_2dsclam311));
	rmlA3 = tmp287;
	rmlA2 = tmp288;
	rmlA1 = tmp289;
	rmlA0 = tmp290;
	rmlFC = tmp286;
	rmlSC = RML_OFFSET(tmp489, -7);
	rmlSP = RML_OFFSET(tmp489, -7);
	RML_TAILCALLQ(Main__bind,4);}}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam311)
{
	void *tmp490;
	RML_ALLOC(tmp490,2,1,Main_2dsclam311);
	{ void *tmp492 = rmlSC;
	{ void *tmp225 = RML_FETCH(RML_OFFSET(tmp492, 1));
	{ void *tmp286 = RML_FETCH(RML_OFFSET(tmp492, 2));
	{ void *tmp287 = RML_FETCH(RML_OFFSET(tmp492, 3));
	{ void *tmp288 = RML_FETCH(RML_OFFSET(tmp492, 4));
	{ void *tmp289 = RML_FETCH(RML_OFFSET(tmp492, 5));
	{ void *tmp291 = RML_FETCH(RML_OFFSET(tmp492, 6));
	{ void *tmp491 = RML_OFFSET(tmp492, 7);
	{ void *tmp293 = rmlA0;
	RML_STORE(tmp490, RML_IMMEDIATE(RML_STRUCTHDR(1,0)));
	RML_STORE(RML_OFFSET(tmp490, 1), tmp291);
	{ void *tmp297 = RML_TAGPTR(tmp490);
	RML_STORE(RML_OFFSET(tmp491, -1), tmp293);
	RML_STORE(RML_OFFSET(tmp491, -2), tmp286);
	RML_STORE(RML_OFFSET(tmp491, -3), tmp225);
	RML_STORE(RML_OFFSET(tmp491, -4), RML_LABVAL(Main_2dsclam310));
	rmlA3 = tmp297;
	rmlA2 = tmp287;
	rmlA1 = tmp288;
	rmlA0 = tmp289;
	rmlFC = tmp286;
	rmlSC = RML_OFFSET(tmp491, -4);
	rmlSP = RML_OFFSET(tmp491, -4);
	RML_TAILCALLQ(Absyn__bindHOOK1,4);}}}}}}}}}}
}
RML_END_LABEL

static RML_BEGIN_LABEL(Main_2dsclam310)
{
	void *tmp493;
	RML_ALLOC(tmp493,3,1,Main_2dsclam310);
	{ void *tmp495 = rmlSC;
	{ void *tmp225 = RML_FETCH(RML_OFFSET(tmp495, 1));
	{ void *tmp286 = RML_FETCH(RML_OFFSET(tmp495, 2));
	{ void *tmp293 = RML_FETCH(RML_OFFSET(tmp495, 3));
	{ void *tmp494 = RML_OFFSET(tmp495, 4);
	{ void *tmp299 = rmlA0;
	RML_STORE(tmp493, RML_IMMEDIATE(RML_STRUCTHDR(2,1)));
	RML_STORE(RML_OFFSET(tmp493, 1), tmp299);
	RML_STORE(RML_OFFSET(tmp493, 2), RML_REFSTRUCTLIT(lit0));
	{ void *tmp303 = RML_TAGPTR(tmp493);
	rmlA1 = tmp293;
	rmlA0 = tmp303;
	rmlFC = tmp286;
	rmlSC = tmp225;
	rmlSP = tmp494;
	RML_TAILCALLQ(RML__list_5fappend,2);}}}}}}}
}
RML_END_LABEL
